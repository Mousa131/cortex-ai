-- ============================================================
--   Cortex AI — Database Schema (PostgreSQL / Neon)
-- ============================================================

-- جدول السيرفرات (Guilds) المفعّل فيها البوت
CREATE TABLE IF NOT EXISTS guilds (
  guild_id        VARCHAR(32) PRIMARY KEY,        -- Discord Guild ID
  guild_name      VARCHAR(100),
  guild_icon      VARCHAR(255),
  owner_discord_id VARCHAR(32),                    -- صاحب السيرفر بديسكورد (للمرجعية فقط)

  -- إعدادات البوت
  bot_name        VARCHAR(50)  DEFAULT 'Cortex AI',
  system_prompt   TEXT         DEFAULT 'أنت مساعد ذكي ودود. أجب بإيجاز ووضوح.',
  language        VARCHAR(5)   DEFAULT 'ar',       -- ar | en
  is_active       BOOLEAN      DEFAULT TRUE,       -- تشغيل/إيقاف البوت بهذا السيرفر

  -- وضع العمل: thread (ثريد خاص لكل مستخدم) أو channel (روم ثابت)
  mode            VARCHAR(10)  DEFAULT 'thread',   -- thread | channel
  bound_channel_id VARCHAR(32),                    -- الروم المربوط (لو mode=channel أو لزر بدء المحادثة)

  -- AI tuning
  temperature     NUMERIC(2,1) DEFAULT 0.4,
  max_tokens      INTEGER      DEFAULT 600,

  created_at      TIMESTAMPTZ  DEFAULT now(),
  updated_at      TIMESTAMPTZ  DEFAULT now()
);

-- جدول صلاحيات الأعضاء على كل سيرفر (من تقدر يعدل من الداشبورد)
-- نخزّنها كـ cache بسيط بدل ما نطلب Discord API كل مرة
CREATE TABLE IF NOT EXISTS guild_managers (
  id              SERIAL PRIMARY KEY,
  guild_id        VARCHAR(32) NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
  discord_user_id VARCHAR(32) NOT NULL,
  permission_bit  BIGINT,                          -- raw permissions من Discord (للتحقق من MANAGE_GUILD)
  updated_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(guild_id, discord_user_id)
);

-- جدول المستخدمين (لوحة التحكم) — يُنشأ/يُحدّث عند كل تسجيل دخول Discord
CREATE TABLE IF NOT EXISTS users (
  discord_id      VARCHAR(32) PRIMARY KEY,
  username        VARCHAR(100),
  avatar          VARCHAR(255),
  access_token    TEXT,                            -- مشفّر/مؤقت — يُستخدم لجلب سيرفرات المستخدم من Discord API
  refresh_token   TEXT,
  token_expires_at TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT now(),
  last_login_at   TIMESTAMPTZ DEFAULT now()
);

-- جلسات المحادثة النشطة (تاريخ كل ثريد/قناة) — اختياري نخزنها بالـ DB
-- بدل الميموري عشان ما تضيع لو البوت أعاد التشغيل
CREATE TABLE IF NOT EXISTS sessions (
  id              SERIAL PRIMARY KEY,
  guild_id        VARCHAR(32) NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
  thread_id       VARCHAR(32) NOT NULL,
  owner_discord_id VARCHAR(32) NOT NULL,
  history         JSONB DEFAULT '[]',               -- [{role, content}, ...]
  created_at      TIMESTAMPTZ DEFAULT now(),
  updated_at      TIMESTAMPTZ DEFAULT now(),
  UNIQUE(guild_id, thread_id)
);

-- سجل استخدام بسيط (للإحصائيات بالداشبورد لاحقاً: كم رسالة، كم سيرفر نشط، إلخ)
CREATE TABLE IF NOT EXISTS usage_logs (
  id              SERIAL PRIMARY KEY,
  guild_id        VARCHAR(32) REFERENCES guilds(guild_id) ON DELETE CASCADE,
  discord_user_id VARCHAR(32),
  question_chars  INTEGER,
  reply_chars     INTEGER,
  tokens_used     INTEGER,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_guild_managers_user ON guild_managers(discord_user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_thread ON sessions(thread_id);
CREATE INDEX IF NOT EXISTS idx_usage_logs_guild ON usage_logs(guild_id);
