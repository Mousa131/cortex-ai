// ============================================================
//   Cortex AI — Multi-Tenant Discord Bot
//   discord.js v14 + Mistral AI + PostgreSQL (Neon)
//   كل سيرفر له برومت وإعدادات مستقلة تُقرأ من الداتابيس
// ============================================================
import 'dotenv/config';
import {
  Client, GatewayIntentBits, Partials,
  REST, Routes, SlashCommandBuilder,
  EmbedBuilder, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, PermissionFlagsBits, ThreadAutoArchiveDuration,
  ChannelType,
} from 'discord.js';
import logger from '../shared/logger.js';
import { askMistral } from '../shared/mistral.js';
import { getOrCreateGuild, getGuild, deactivateGuild } from '../shared/guilds.js';
import { createSession, getSession, appendToHistory, deleteSession } from '../shared/sessions.js';
import { upsertManagerPermission } from '../shared/permissions.js';

const TOKEN = process.env.DISCORD_BOT_TOKEN;

// صاحب كل ثريد (طبقة حماية إضافية بمستوى الكود — احتياط لو فشلت صلاحيات Discord)
// thread_id → discord_user_id
const threadOwners = new Map();

// ── إنشاء الكلاينت ─────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.ThreadMember],
});

// ── تسجيل الأوامر (Global — تشتغل بكل سيرفر يدخله البوت) ──
async function registerGlobalCommands() {
  const commands = [
    new SlashCommandBuilder()
      .setName('setup')
      .setDescription('إعداد قناة دعم الذكاء الاصطناعي / Setup AI support channel')
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
      .toJSON(),
  ];

  const rest = new REST({ version: '10' }).setToken(TOKEN);
  try {
    await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
    logger.info('Global slash commands registered ✅');
  } catch (e) {
    logger.error('Failed to register commands', { error: e.message });
  }
}

// ── بناء رسالة الـ Setup حسب لغة السيرفر ───────────────────
function buildSetupMessage(guild) {
  const isAr = guild.language !== 'en';

  const embed = new EmbedBuilder()
    .setColor(0x00FF66)
    .setTitle(isAr ? `🤖 ${guild.bot_name}` : `🤖 ${guild.bot_name}`)
    .setDescription(
      isAr
        ? '> اضغط الزر تحت لبدء محادثة خاصة مع المساعد الذكي.\n\nراح يفتح لك ثريد خاص فيك تقدر تسأل فيه أي سؤال.'
        : '> Click the button below to start a private chat with the AI assistant.\n\nA private thread will open just for you.'
    )
    .setFooter({ text: guild.bot_name })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('new_chat')
      .setLabel(isAr ? '💬 بدء محادثة جديدة' : '💬 Start New Chat')
      .setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row] };
}

// ── إنشاء Thread جديد ──────────────────────────────────────
async function createChatThread(interaction, guild) {
  const user = interaction.user;
  const channel = interaction.channel;
  const isAr = guild.language !== 'en';

  if (!channel.threads) {
    return interaction.reply({
      content: isAr ? '⚠️ هذه القناة لا تدعم الثريدات.' : '⚠️ This channel does not support threads.',
      ephemeral: true,
    });
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const thread = await channel.threads.create({
      name: `💬 ${user.username} — ${guild.bot_name}`,
      type: ChannelType.PrivateThread,
      autoArchiveDuration: ThreadAutoArchiveDuration.OneHour,
      invitable: false,
      reason: `AI support session for ${user.tag}`,
    });

    await thread.members.add(user.id);

    const welcomeEmbed = new EmbedBuilder()
      .setColor(0x00FF66)
      .setTitle(isAr ? `مرحباً ${user.displayName}! 👋` : `Welcome ${user.displayName}! 👋`)
      .setDescription(
        isAr
          ? `أنا ${guild.bot_name} 🤖\n\nاكتب سؤالك هنا وسأجيبك مباشرة!\n\n_هذا الثريد خاص بك فقط ويُغلق تلقائياً بعد ساعة من عدم النشاط._`
          : `I'm ${guild.bot_name} 🤖\n\nType your question and I'll reply directly!\n\n_This thread is private to you and auto-archives after 1 hour of inactivity._`
      )
      .setFooter({ text: guild.bot_name })
      .setTimestamp();

    await thread.send({ embeds: [welcomeEmbed] });

    await createSession(guild.guild_id, thread.id, user.id);
    threadOwners.set(thread.id, user.id);

    logger.info('Thread created', { guildId: guild.guild_id, threadId: thread.id, user: user.tag });

    await interaction.editReply({
      content: isAr ? `✅ تم إنشاء ثريدك الخاص! ${thread}` : `✅ Your private thread is ready! ${thread}`,
    });

  } catch (e) {
    logger.error('Failed to create thread', { error: e.message, user: user.tag });
    const hint = e.message?.includes('Missing Permissions')
      ? (isAr ? ' (تأكد أن البوت يملك صلاحية "Create Private Threads")' : ' (Check the bot has "Create Private Threads" permission)')
      : '';
    await interaction.editReply({
      content: (isAr ? '⚠️ حصل خطأ أثناء إنشاء الثريد، حاول مرة ثانية.' : '⚠️ Failed to create thread, try again.') + hint,
    });
  }
}

// ── معالجة الرسائل داخل الثريدات ──────────────────────────
async function handleThreadMessage(message) {
  const thread = message.channel;
  if (message.author.bot) return;

  const session = await getSession(thread.id);
  if (!session) return;

  // طبقة حماية إضافية: تجاهل أي رسالة من غير صاحب الثريد
  const ownerId = threadOwners.get(thread.id) || session.owner_discord_id;
  if (ownerId && message.author.id !== ownerId) {
    try { await message.delete(); } catch { /* تجاهل بصمت */ }
    return;
  }

  const guild = await getGuild(session.guild_id);
  if (!guild || !guild.is_active) return;

  const userText = message.content.trim();
  if (!userText) return;

  await thread.sendTyping();

  // نجهز التاريخ المرسل لـ Mistral من قاعدة البيانات
  const history = (session.history || []).map(h => ({ role: h.role, content: h.content }));
  history.push({ role: 'user', content: userText });

  try {
    const { reply } = await askMistral(history, guild.system_prompt, {
      temperature: parseFloat(guild.temperature) || 0.4,
      maxTokens: guild.max_tokens || 600,
    });

    await appendToHistory(thread.id, userText, reply);

    if (reply.length <= 1990) {
      await thread.send(reply);
    } else {
      const chunks = reply.match(/.{1,1990}/gs) || [];
      for (const chunk of chunks) await thread.send(chunk);
    }

    logger.info('AI replied in thread', {
      guildId: guild.guild_id,
      threadId: thread.id,
      user: message.author.tag,
      questionLength: userText.length,
      replyLength: reply.length,
    });

  } catch (e) {
    logger.error('Error in thread message handler', { error: e.message });
    const isAr = guild.language !== 'en';
    await thread.send(isAr ? '⚠️ حصل خطأ، حاول مرة ثانية.' : '⚠️ Something went wrong, try again.');
  }
}

// ── الأحداث ────────────────────────────────────────────────
client.once('ready', async () => {
  logger.info(`✅ Bot online as ${client.user.tag}`);
  await registerGlobalCommands();

  client.user.setPresence({
    activities: [{ name: 'Cortex AI 🧠', type: 3 }],
    status: 'online',
  });
});

// عند انضمام البوت لسيرفر جديد → أنشئ صف افتراضي له + سجّل صاحب السيرفر كمدير افتراضي
client.on('guildCreate', async (guild) => {
  try {
    await getOrCreateGuild(guild.id, guild.name, guild.ownerId);
    await upsertManagerPermission(guild.id, guild.ownerId, '8'); // ADMINISTRATOR bit لصاحب السيرفر
    logger.info('Bot added to new guild', { guildId: guild.id, name: guild.name });
  } catch (e) {
    logger.error('Failed to register new guild', { error: e.message, guildId: guild.id });
  }
});

// عند إزالة البوت من سيرفر → عطّله بدل ما نحذف بياناته (يحتفظ بإعداداته لو رجع)
client.on('guildDelete', async (guild) => {
  try {
    await deactivateGuild(guild.id);
    logger.info('Bot removed from guild, deactivated', { guildId: guild.id });
  } catch (e) {
    logger.error('Failed to deactivate guild', { error: e.message, guildId: guild.id });
  }
});

// أمر /setup + زر بدء المحادثة
client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand() && interaction.commandName === 'setup') {
    if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: '❌ هذا الأمر يتطلب صلاحية إدارة السيرفر.', ephemeral: true });
    }

    const guild = await getOrCreateGuild(interaction.guild.id, interaction.guild.name, interaction.guild.ownerId);

    await interaction.channel.send(buildSetupMessage(guild));
    await interaction.reply({
      content: guild.language === 'en' ? '✅ Support message sent!' : '✅ تم إرسال رسالة الدعم!',
      ephemeral: true,
    });

    logger.info('/setup used', { guildId: interaction.guild.id, user: interaction.user.tag });
  }

  if (interaction.isButton() && interaction.customId === 'new_chat') {
    const guild = await getOrCreateGuild(interaction.guild.id, interaction.guild.name, interaction.guild.ownerId);
    if (!guild.is_active) {
      return interaction.reply({
        content: guild.language === 'en' ? '⚠️ The bot is currently disabled on this server.' : '⚠️ البوت متوقف حالياً بهذا السيرفر.',
        ephemeral: true,
      });
    }
    await createChatThread(interaction, guild);
  }
});

// رسائل الثريدات
client.on('messageCreate', async message => {
  if (message.author.bot) return;
  if (!message.channel.isThread()) return;
  await handleThreadMessage(message);
});

// حذف الجلسة عند أرشفة الثريد
client.on('threadUpdate', async (oldThread, newThread) => {
  if (newThread.archived) {
    threadOwners.delete(newThread.id);
    await deleteSession(newThread.id);
    logger.info('Session cleared (thread archived)', { threadId: newThread.id });
  }
});

// عند انضمام عضو جديد للسيرفر لا شيء خاص — محجوز للتوسعة المستقبلية

// ── تشغيل البوت ────────────────────────────────────────────
if (!TOKEN) { logger.error('❌ DISCORD_BOT_TOKEN غير موجود في .env'); process.exit(1); }
if (!process.env.MISTRAL_API_KEY) { logger.error('❌ MISTRAL_API_KEY غير موجود في .env'); process.exit(1); }
if (!process.env.DATABASE_URL) { logger.error('❌ DATABASE_URL غير موجود في .env'); process.exit(1); }

client.login(TOKEN).catch(e => {
  logger.error('Login failed', { error: e.message });
  process.exit(1);
});
