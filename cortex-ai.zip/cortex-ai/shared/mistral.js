// ============================================================
//   Cortex AI — Mistral AI Handler (shared)
//   نفس فكرة المشروع السابق، لكن يدعم system prompt مختلف لكل سيرفر
// ============================================================
import 'dotenv/config';

const MISTRAL_URL = 'https://api.mistral.ai/v1/chat/completions';
const MODEL = 'mistral-small-latest';

/**
 * أرسل محادثة لـ Mistral وارجع الرد
 * @param {Array} history - [{role:'user'|'assistant', content:'...'}]
 * @param {string} systemPrompt - البرومت الخاص بهذا السيرفر
 * @param {object} opts - { temperature, maxTokens }
 * @returns {Promise<string>}
 */
export async function askMistral(history, systemPrompt, opts = {}) {
  const { temperature = 0.4, maxTokens = 600 } = opts;

  const messages = [
    { role: 'system', content: systemPrompt },
    ...history,
  ];

  try {
    const res = await fetch(MISTRAL_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.MISTRAL_API_KEY}`,
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        max_tokens: maxTokens,
        temperature,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error('Mistral API error', res.status, err);
      return { ok: false, reply: '⚠️ حصل خطأ في الذكاء الاصطناعي، حاول مرة ثانية.' };
    }

    const data = await res.json();
    const reply = data?.choices?.[0]?.message?.content?.trim();

    if (!reply) return { ok: false, reply: '⚠️ ما جاء رد من الذكاء الاصطناعي، حاول مجدداً.' };

    return { ok: true, reply, tokens: data?.usage?.total_tokens || 0 };

  } catch (e) {
    console.error('Mistral fetch failed', e.message);
    return { ok: false, reply: '⚠️ تعذر الاتصال بالذكاء الاصطناعي حالياً.' };
  }
}
