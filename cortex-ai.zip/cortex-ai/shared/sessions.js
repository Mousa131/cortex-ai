// ============================================================
//   Cortex AI — Sessions Repository
//   تاريخ المحادثة لكل ثريد، مخزّن بالـ DB بدل الميموري
//   (يضمن استمرار الجلسة حتى لو البوت أعاد التشغيل)
// ============================================================
import { query } from './db.js';

const MAX_HISTORY = 10; // 5 ذهاب + 5 إياب

export async function createSession(guildId, threadId, ownerDiscordId) {
  await query(
    `INSERT INTO sessions (guild_id, thread_id, owner_discord_id, history)
     VALUES ($1, $2, $3, '[]')
     ON CONFLICT (guild_id, thread_id) DO NOTHING`,
    [guildId, threadId, ownerDiscordId]
  );
}

export async function getSession(threadId) {
  const res = await query('SELECT * FROM sessions WHERE thread_id = $1', [threadId]);
  return res.rows[0] || null;
}

export async function appendToHistory(threadId, userMessage, assistantReply) {
  const session = await getSession(threadId);
  if (!session) return null;

  let history = session.history || [];
  history.push({ role: 'user', content: userMessage });
  history.push({ role: 'assistant', content: assistantReply });

  if (history.length > MAX_HISTORY) {
    history = history.slice(history.length - MAX_HISTORY);
  }

  await query(
    'UPDATE sessions SET history = $1, updated_at = now() WHERE thread_id = $2',
    [JSON.stringify(history), threadId]
  );
  return history;
}

export async function deleteSession(threadId) {
  await query('DELETE FROM sessions WHERE thread_id = $1', [threadId]);
}
