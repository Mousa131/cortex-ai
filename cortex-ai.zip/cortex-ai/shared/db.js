// ============================================================
//   Cortex AI — Database Connection (shared by bot + dashboard)
// ============================================================
import pg from 'pg';
import 'dotenv/config';

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('❌ DATABASE_URL غير موجود في .env');
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // Neon يتطلب SSL؛ موروث ضمن sslmode=require بالـ connection string
  max: 10,
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => {
  console.error('❌ Unexpected DB pool error:', err.message);
});

/**
 * تنفيذ استعلام بسيط
 */
export async function query(text, params) {
  return pool.query(text, params);
}

/**
 * تشغيل ملف schema.sql لإنشاء الجداول إن لم تكن موجودة
 */
export async function ensureSchema() {
  const fs = await import('fs');
  const path = await import('url');
  const schemaPath = new URL('../database/schema.sql', import.meta.url);
  const sql = fs.readFileSync(schemaPath, 'utf-8');
  await pool.query(sql);
}
