// ============================================================
//   Logger — نظام اللوق المشترك
// ============================================================
import winston from 'winston';
import { existsSync, mkdirSync } from 'fs';

if (!existsSync('./logs')) mkdirSync('./logs');

const fmt = winston.format;

const logger = winston.createLogger({
  level: 'info',
  format: fmt.combine(
    fmt.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    fmt.errors({ stack: true }),
    fmt.json()
  ),
  transports: [
    new winston.transports.File({ filename: './logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: './logs/combined.log' }),
  ],
});

logger.add(new winston.transports.Console({
  format: fmt.combine(
    fmt.colorize(),
    fmt.printf(({ level, message, timestamp, ...meta }) => {
      const extra = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
      return `[${timestamp}] ${level}: ${message}${extra}`;
    })
  )
}));

export default logger;
