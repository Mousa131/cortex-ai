// ============================================================
//   Cortex AI — Guild Repository
//   كل العمليات على جدول guilds في مكان واحد (يستخدمه البوت + الداشبورد)
// ============================================================
import { query } from './db.js';

const DEFAULT_PROMPT = 'أنت مساعد ذكي ودود اسمك Cortex AI. أجب بإيجاز ووضوح وبأسلوب مهذب.';

/**
 * جلب إعدادات سيرفر، أو إنشاء صف افتراضي له إذا ما كان موجود
 */
export async function getOrCreateGuild(guildId, guildName = null, ownerDiscordId = null) {
  const existing = await query('SELECT * FROM guilds WHERE guild_id = $1', [guildId]);
  if (existing.rows.length) return existing.rows[0];

  const inserted = await query(
    `INSERT INTO guilds (guild_id, guild_name, owner_discord_id, system_prompt)
     VALUES ($1, $2, $3, $4)
     RETURNING *`,
    [guildId, guildName, ownerDiscordId, DEFAULT_PROMPT]
  );
  return inserted.rows[0];
}

export async function getGuild(guildId) {
  const res = await query('SELECT * FROM guilds WHERE guild_id = $1', [guildId]);
  return res.rows[0] || null;
}

export async function updateGuildSettings(guildId, fields) {
  // فقط الأعمدة المسموح تعديلها من الداشبورد (whitelist — حماية من تعديل أعمدة حساسة)
  const allowed = ['bot_name', 'system_prompt', 'language', 'is_active', 'mode', 'bound_channel_id', 'temperature', 'max_tokens'];
  const keys = Object.keys(fields).filter(k => allowed.includes(k));
  if (!keys.length) return getGuild(guildId);

  const setClause = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
  const values = keys.map(k => fields[k]);

  const res = await query(
    `UPDATE guilds SET ${setClause}, updated_at = now() WHERE guild_id = $1 RETURNING *`,
    [guildId, ...values]
  );
  return res.rows[0];
}

export async function deactivateGuild(guildId) {
  await query('UPDATE guilds SET is_active = FALSE, updated_at = now() WHERE guild_id = $1', [guildId]);
}

export async function listGuildsByIds(guildIds) {
  if (!guildIds.length) return [];
  const res = await query('SELECT * FROM guilds WHERE guild_id = ANY($1)', [guildIds]);
  return res.rows;
}
