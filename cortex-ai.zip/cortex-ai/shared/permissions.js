// ============================================================
//   Cortex AI — Guild Managers Repository
//   التحقق من صلاحية "من يقدر يعدل على أي سيرفر" — هذا قلب نظام الأمان
// ============================================================
import { query } from './db.js';

const MANAGE_GUILD_BIT = 0x20n; // Discord permission bit لـ MANAGE_GUILD

/**
 * يحسب هل صلاحية الـ raw permissions تحتوي MANAGE_GUILD أو ADMINISTRATOR
 */
export function hasManagePermission(permissionString) {
  try {
    const perms = BigInt(permissionString);
    const ADMINISTRATOR_BIT = 0x8n;
    return (perms & MANAGE_GUILD_BIT) === MANAGE_GUILD_BIT || (perms & ADMINISTRATOR_BIT) === ADMINISTRATOR_BIT;
  } catch {
    return false;
  }
}

/**
 * يحدّث/يخزّن كاش الصلاحية لمستخدم على سيرفر معيّن
 * (يُستدعى بعد كل تسجيل دخول، بناءً على بيانات Discord API الحقيقية)
 */
export async function upsertManagerPermission(guildId, discordUserId, permissionBit) {
  await query(
    `INSERT INTO guild_managers (guild_id, discord_user_id, permission_bit, updated_at)
     VALUES ($1, $2, $3, now())
     ON CONFLICT (guild_id, discord_user_id)
     DO UPDATE SET permission_bit = $3, updated_at = now()`,
    [guildId, discordUserId, permissionBit]
  );
}

/**
 * التحقق الفعلي: هل هذا المستخدم يقدر يدير هذا السيرفر؟
 * يُستخدم في كل route حساس بالداشبورد قبل أي قراءة/تعديل
 */
export async function canManageGuild(guildId, discordUserId) {
  const res = await query(
    'SELECT permission_bit FROM guild_managers WHERE guild_id = $1 AND discord_user_id = $2',
    [guildId, discordUserId]
  );
  if (!res.rows.length) return false;
  return hasManagePermission(res.rows[0].permission_bit);
}
