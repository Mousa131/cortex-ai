// ============================================================
//   Cortex AI — Users Repository
// ============================================================
import { query } from './db.js';

/**
 * إنشاء/تحديث مستخدم بعد تسجيل دخول Discord ناجح
 * ملاحظة أمان: access_token / refresh_token تُخزّن مؤقتاً فقط لجلب سيرفرات
 * المستخدم من Discord API — لا تُعرض أبداً للفرونت إند
 */
export async function upsertUser({ discordId, username, avatar, accessToken, refreshToken, expiresIn }) {
  const expiresAt = new Date(Date.now() + expiresIn * 1000);
  await query(
    `INSERT INTO users (discord_id, username, avatar, access_token, refresh_token, token_expires_at, last_login_at)
     VALUES ($1, $2, $3, $4, $5, $6, now())
     ON CONFLICT (discord_id)
     DO UPDATE SET username = $2, avatar = $3, access_token = $4, refresh_token = $5,
                   token_expires_at = $6, last_login_at = now()`,
    [discordId, username, avatar, accessToken, refreshToken, expiresAt]
  );
}

export async function getUser(discordId) {
  const res = await query('SELECT * FROM users WHERE discord_id = $1', [discordId]);
  return res.rows[0] || null;
}

export async function getPublicUser(discordId) {
  // نسخة آمنة بدون التوكنات — هذي فقط تُرسل للفرونت إند
  const res = await query(
    'SELECT discord_id, username, avatar, last_login_at FROM users WHERE discord_id = $1',
    [discordId]
  );
  return res.rows[0] || null;
}
