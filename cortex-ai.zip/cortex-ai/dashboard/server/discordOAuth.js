// ============================================================
//   Cortex AI Dashboard — Discord OAuth2 Helper
// ============================================================
const DISCORD_API = 'https://discord.com/api/v10';

const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const REDIRECT_URI = process.env.DISCORD_REDIRECT_URI;

/**
 * رابط بدء تسجيل الدخول عبر Discord
 */
export function getAuthorizeUrl(state) {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'identify guilds',
    state,
  });
  return `https://discord.com/oauth2/authorize?${params.toString()}`;
}

/**
 * تبديل الـ authorization code بـ access/refresh token
 */
export async function exchangeCode(code) {
  const body = new URLSearchParams({
    client_id: CLIENT_ID,
    client_secret: CLIENT_SECRET,
    grant_type: 'authorization_code',
    code,
    redirect_uri: REDIRECT_URI,
  });

  const res = await fetch(`${DISCORD_API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Discord token exchange failed: ${res.status} ${err}`);
  }

  return res.json(); // { access_token, refresh_token, expires_in, ... }
}

/**
 * جلب بيانات المستخدم نفسه (@me)
 */
export async function fetchDiscordUser(accessToken) {
  const res = await fetch(`${DISCORD_API}/users/@me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Failed to fetch Discord user: ${res.status}`);
  return res.json();
}

/**
 * جلب قائمة سيرفرات المستخدم (فقط اللي عنده فيها صلاحيات)
 */
export async function fetchUserGuilds(accessToken) {
  const res = await fetch(`${DISCORD_API}/users/@me/guilds`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Failed to fetch user guilds: ${res.status}`);
  return res.json(); // [{id, name, icon, owner, permissions, ...}]
}

/**
 * بناء رابط دعوة البوت لسيرفر معيّن (مسبق التحديد بالصلاحيات المطلوبة)
 */
export function getBotInviteUrl(guildId) {
  // صلاحيات البوت: View Channels, Send Messages, Read Message History,
  // Create Private Threads, Send Messages in Threads, Manage Threads,
  // Embed Links, Use External Emojis
  const PERMISSIONS = '326417525824';
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    permissions: PERMISSIONS,
    scope: 'bot applications.commands',
    guild_id: guildId,
    disable_guild_select: 'true',
  });
  return `https://discord.com/oauth2/authorize?${params.toString()}`;
}
