// ============================================================
//   Cortex AI Dashboard — Guild Routes
//   عرض سيرفرات المستخدم + تعديل إعدادات سيرفر معيّن
// ============================================================
import { Router } from 'express';
import { requireAuth } from './auth.js';
import { requireGuildManager } from './guildAuth.js';
import { fetchUserGuilds } from './discordOAuth.js';
import { getUser } from '../../shared/users.js';
import { getGuild, updateGuildSettings, listGuildsByIds } from '../../shared/guilds.js';
import { upsertManagerPermission, hasManagePermission } from '../../shared/permissions.js';
import { getBotInviteUrl } from './discordOAuth.js';
import { query } from '../../shared/db.js';
import logger from '../../shared/logger.js';

const router = Router();

/**
 * GET /api/guilds
 * يرجّع كل سيرفرات المستخدم (من Discord) مع تحديد:
 * - هل البوت موجود فيها (installed: true/false)
 * - هل المستخدم يملك صلاحية الإدارة فيها (canManage: true/false)
 */
router.get('/', requireAuth, async (req, res) => {
  try {
    const user = await getUser(req.discordUserId);
    if (!user || !user.access_token) return res.status(401).json({ error: 'unauthorized' });

    const discordGuilds = await fetchUserGuilds(user.access_token);

    // فلترة: بس سيرفرات يملك فيها المستخدم MANAGE_GUILD أو هو المالك
    const manageable = discordGuilds.filter(g => g.owner || hasManagePermission(g.permissions));

    const installedGuilds = await listGuildsByIds(manageable.map(g => g.id));
    const installedMap = new Map(installedGuilds.map(g => [g.guild_id, g]));

    // نحدّث كاش الصلاحيات بالتوازي (لو السيرفر مفعّل فيه البوت)
    for (const g of manageable) {
      if (installedMap.has(g.id)) {
        await upsertManagerPermission(g.id, req.discordUserId, g.permissions);
      }
    }

    const result = manageable.map(g => ({
      id: g.id,
      name: g.name,
      icon: g.icon ? `https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png` : null,
      installed: installedMap.has(g.id),
      isActive: installedMap.get(g.id)?.is_active ?? null,
      inviteUrl: installedMap.has(g.id) ? null : getBotInviteUrl(g.id),
    }));

    res.json(result);
  } catch (e) {
    logger.error('Failed to list guilds', { error: e.message, user: req.discordUserId });
    res.status(500).json({ error: 'failed_to_fetch_guilds' });
  }
});

/**
 * GET /api/guilds/:guildId/settings
 * إعدادات سيرفر معيّن — يتطلب صلاحية إدارة (requireGuildManager)
 */
router.get('/:guildId/settings', requireAuth, requireGuildManager, async (req, res) => {
  const guild = await getGuild(req.params.guildId);
  if (!guild) return res.status(404).json({ error: 'guild_not_found' });

  // لا نُرجع أي حقل حساس (لا يوجد API keys هنا أصلاً بجدول guilds، لكن نتأكد)
  const { guild_id, guild_name, guild_icon, bot_name, system_prompt, language,
          is_active, mode, bound_channel_id, temperature, max_tokens, created_at, updated_at } = guild;

  res.json({
    guildId: guild_id, guildName: guild_name, guildIcon: guild_icon,
    botName: bot_name, systemPrompt: system_prompt, language,
    isActive: is_active, mode, boundChannelId: bound_channel_id,
    temperature: parseFloat(temperature), maxTokens: max_tokens,
    createdAt: created_at, updatedAt: updated_at,
  });
});

/**
 * PATCH /api/guilds/:guildId/settings
 * تحديث الإعدادات — كل القيم تُتحقق منها قبل الحفظ
 */
router.patch('/:guildId/settings', requireAuth, requireGuildManager, async (req, res) => {
  const { botName, systemPrompt, language, isActive, mode, boundChannelId, temperature, maxTokens } = req.body;

  // تحقق أساسي من المدخلات (validation)
  const fields = {};

  if (botName !== undefined) {
    if (typeof botName !== 'string' || botName.length < 1 || botName.length > 50) {
      return res.status(400).json({ error: 'invalid_bot_name', message: 'اسم البوت يجب أن يكون بين 1 و 50 حرف' });
    }
    fields.bot_name = botName;
  }

  if (systemPrompt !== undefined) {
    if (typeof systemPrompt !== 'string' || systemPrompt.length < 1 || systemPrompt.length > 4000) {
      return res.status(400).json({ error: 'invalid_prompt', message: 'البرومت يجب أن يكون بين 1 و 4000 حرف' });
    }
    fields.system_prompt = systemPrompt;
  }

  if (language !== undefined) {
    if (!['ar', 'en'].includes(language)) {
      return res.status(400).json({ error: 'invalid_language' });
    }
    fields.language = language;
  }

  if (isActive !== undefined) {
    fields.is_active = Boolean(isActive);
  }

  if (mode !== undefined) {
    if (!['thread', 'channel'].includes(mode)) {
      return res.status(400).json({ error: 'invalid_mode' });
    }
    fields.mode = mode;
  }

  if (boundChannelId !== undefined) {
    if (boundChannelId !== null && !/^\d{17,20}$/.test(boundChannelId)) {
      return res.status(400).json({ error: 'invalid_channel_id' });
    }
    fields.bound_channel_id = boundChannelId;
  }

  if (temperature !== undefined) {
    const t = parseFloat(temperature);
    if (isNaN(t) || t < 0 || t > 1) {
      return res.status(400).json({ error: 'invalid_temperature', message: 'يجب أن تكون بين 0 و 1' });
    }
    fields.temperature = t;
  }

  if (maxTokens !== undefined) {
    const m = parseInt(maxTokens, 10);
    if (isNaN(m) || m < 50 || m > 2000) {
      return res.status(400).json({ error: 'invalid_max_tokens', message: 'يجب أن تكون بين 50 و 2000' });
    }
    fields.max_tokens = m;
  }

  if (!Object.keys(fields).length) {
    return res.status(400).json({ error: 'no_valid_fields' });
  }

  const updated = await updateGuildSettings(req.params.guildId, fields);

  logger.info('Guild settings updated', {
    guildId: req.params.guildId,
    updatedBy: req.discordUserId,
    fields: Object.keys(fields),
  });

  res.json({ ok: true, guild: updated });
});

/**
 * GET /api/guilds/:guildId/stats
 * إحصائيات بسيطة (للوحة المعلومات)
 */
router.get('/:guildId/stats', requireAuth, requireGuildManager, async (req, res) => {
  const totalRes = await query(
    `SELECT COUNT(*)::int AS total_messages,
            COALESCE(SUM(tokens_used), 0)::int AS total_tokens
     FROM usage_logs WHERE guild_id = $1`,
    [req.params.guildId]
  );
  const activeSessionsRes = await query(
    'SELECT COUNT(*)::int AS active_sessions FROM sessions WHERE guild_id = $1',
    [req.params.guildId]
  );

  res.json({
    totalMessages: totalRes.rows[0]?.total_messages || 0,
    totalTokens: totalRes.rows[0]?.total_tokens || 0,
    activeSessions: activeSessionsRes.rows[0]?.active_sessions || 0,
  });
});

export default router;
