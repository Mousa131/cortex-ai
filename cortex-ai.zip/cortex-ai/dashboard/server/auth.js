// ============================================================
//   Cortex AI Dashboard — Auth Middleware
//   الجلسة محفوظة بـ HttpOnly cookie موقّعة بـ JWT
//   (أأمن من localStorage ضد هجمات XSS)
// ============================================================
import jwt from 'jsonwebtoken';

const SESSION_SECRET = process.env.SESSION_SECRET;
const COOKIE_NAME = 'cortex_session';
const isProd = process.env.NODE_ENV === 'production';

if (!SESSION_SECRET || SESSION_SECRET.length < 16) {
  throw new Error('❌ SESSION_SECRET غير موجود أو قصير جداً بـ .env — ولّد قيمة عشوائية طويلة');
}

/**
 * ينشئ JWT ويحطه بكوكي HttpOnly + Secure + SameSite
 */
export function createSessionCookie(res, discordUserId) {
  const token = jwt.sign({ sub: discordUserId }, SESSION_SECRET, { expiresIn: '7d' });
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,                       // الفرونت إند (JS) ما يقدر يقرأه — حماية من XSS
    secure: isProd,                       // HTTPS فقط بالإنتاج
    sameSite: 'lax',                      // حماية أساسية من CSRF
    maxAge: 7 * 24 * 60 * 60 * 1000,      // 7 أيام
    path: '/',
  });
}

export function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME, { path: '/' });
}

/**
 * Middleware: يتحقق من الكوكي ويحط req.discordUserId
 * لو ما فيه جلسة صالحة → 401
 */
export function requireAuth(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'unauthorized' });

  try {
    const payload = jwt.verify(token, SESSION_SECRET);
    req.discordUserId = payload.sub;
    next();
  } catch {
    return res.status(401).json({ error: 'unauthorized' });
  }
}

/**
 * نسخة "اختيارية" — ما توقف الطلب لو ما فيه جلسة، بس تحط req.discordUserId لو موجودة
 */
export function optionalAuth(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) return next();
  try {
    const payload = jwt.verify(token, SESSION_SECRET);
    req.discordUserId = payload.sub;
  } catch { /* تجاهل توكن غير صالح */ }
  next();
}
