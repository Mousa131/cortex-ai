// ============================================================
//   Cortex AI Dashboard — Guild Authorization Middleware
//   يتحقق إن المستخدم المسجّل دخوله فعلاً يملك صلاحية MANAGE_GUILD
//   على السيرفر المطلوب، قبل أي قراءة أو تعديل لإعداداته.
//   هذا التحقق يتم بالـ backend دائماً — لا نعتمد على الفرونت إند أبداً.
// ============================================================
import { canManageGuild } from '../../shared/permissions.js';

/**
 * يُستخدم على أي route فيه :guildId بالمسار
 * مثال: GET /api/guilds/:guildId/settings
 */
export async function requireGuildManager(req, res, next) {
  const { guildId } = req.params;
  const userId = req.discordUserId;

  if (!guildId || !userId) {
    return res.status(400).json({ error: 'missing_guild_or_user' });
  }

  const allowed = await canManageGuild(guildId, userId);
  if (!allowed) {
    return res.status(403).json({ error: 'forbidden', message: 'ليس لديك صلاحية إدارة هذا السيرفر' });
  }

  next();
}
