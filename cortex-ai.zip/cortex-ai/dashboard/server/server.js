// ============================================================
//   Cortex AI Dashboard — Express Server
// ============================================================
import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes from './routes.auth.js';
import guildRoutes from './routes.guilds.js';
import { optionalAuth } from './auth.js';
import { ensureSchema } from '../../shared/db.js';
import logger from '../../shared/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const app = express();
const PORT = process.env.PORT || 3000;

// ── أمان أساسي على مستوى الـ headers ───────────────────────
app.disable('x-powered-by'); // لا نكشف إننا نستخدم Express
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY'); // يمنع تضمين الموقع بـ iframe (clickjacking)
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

app.use(express.json({ limit: '100kb' })); // حد أقصى لحجم الـ body — حماية بسيطة من إساءة الاستخدام
app.use(cookieParser());
app.use(optionalAuth);

// ── Routes ───────────────────────────────────────────────
app.use('/auth', authRoutes);
app.use('/api/guilds', guildRoutes);

// نقطة فحص صحة السيرفر (للمراقبة)
app.get('/api/health', (req, res) => res.json({ ok: true }));

// ── ملفات الموقع الثابتة (HTML/CSS/JS) ─────────────────────
app.use(express.static(PUBLIC_DIR));

// أي مسار غير معروف بالـ API يرجع 404 JSON بدل HTML
app.use('/api', (req, res) => res.status(404).json({ error: 'not_found' }));
app.use('/auth', (req, res) => res.status(404).json({ error: 'not_found' }));

// أي مسار صفحة غير معروف → نرجّع index.html (دعم الـ client-side routing البسيط)
app.get('*', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// ── معالج أخطاء عام (يمنع تسريب تفاصيل الأخطاء للمستخدم) ──
app.use((err, req, res, next) => {
  logger.error('Unhandled error', { error: err.message, stack: err.stack, path: req.path });
  res.status(500).json({ error: 'internal_server_error' });
});

// ── تشغيل ───────────────────────────────────────────────
async function start() {
  try {
    await ensureSchema();
    logger.info('✅ Database schema ready');
  } catch (e) {
    logger.error('❌ Failed to ensure DB schema', { error: e.message });
    process.exit(1);
  }

  app.listen(PORT, () => {
    logger.info(`✅ Cortex AI Dashboard running on port ${PORT}`);
  });
}

start();
