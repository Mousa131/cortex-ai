// ============================================================
//   Cortex AI Dashboard — Auth Routes
// ============================================================
import { Router } from 'express';
import crypto from 'crypto';
import {
  getAuthorizeUrl, exchangeCode, fetchDiscordUser, fetchUserGuilds,
} from './discordOAuth.js';
import { createSessionCookie, clearSessionCookie, requireAuth } from './auth.js';
import { upsertUser, getPublicUser } from '../../shared/users.js';
import { upsertManagerPermission } from '../../shared/permissions.js';
import { getOrCreateGuild } from '../../shared/guilds.js';
import { query } from '../../shared/db.js';
import logger from '../../shared/logger.js';

const router = Router();

// بدء تسجيل الدخول — نولّد state عشوائي لحماية CSRF بطلب الـ OAuth نفسه
router.get('/discord', (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  res.cookie('oauth_state', state, { httpOnly: true, sameSite: 'lax', maxAge: 5 * 60 * 1000 });
  res.redirect(getAuthorizeUrl(state));
});

// Discord يرجّع المستخدم هنا بعد الموافقة
router.get('/discord/callback', async (req, res) => {
  const { code, state } = req.query;
  const savedState = req.cookies?.oauth_state;

  if (!code || !state || state !== savedState) {
    return res.status(400).send('⚠️ طلب تسجيل دخول غير صالح (state mismatch). حاول مرة ثانية.');
  }
  res.clearCookie('oauth_state');

  try {
    const tokenData = await exchangeCode(code);
    const discordUser = await fetchDiscordUser(tokenData.access_token);

    await upsertUser({
      discordId: discordUser.id,
      username: discordUser.username,
      avatar: discordUser.avatar,
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      expiresIn: tokenData.expires_in,
    });

    // جلب سيرفرات المستخدم وتحديث كاش الصلاحيات (guild_managers)
    // فقط للسيرفرات اللي عندنا فيها صف guilds أصلاً (يعني البوت موجود فيها)
    const userGuilds = await fetchUserGuilds(tokenData.access_token);
    for (const g of userGuilds) {
      // نحدّث الصلاحية فقط لو السيرفر هذا مفعّل فيه البوت أصلاً
      const existing = await query('SELECT 1 FROM guilds WHERE guild_id = $1', [g.id]);
      if (existing.rows.length) {
        await upsertManagerPermission(g.id, discordUser.id, g.permissions);
      }
    }

    createSessionCookie(res, discordUser.id);
    logger.info('User logged in', { discordId: discordUser.id, username: discordUser.username });

    res.redirect('/dashboard.html');
  } catch (e) {
    logger.error('OAuth callback failed', { error: e.message });
    res.status(500).send('⚠️ حصل خطأ أثناء تسجيل الدخول، حاول مرة ثانية.');
  }
});

router.post('/logout', requireAuth, (req, res) => {
  clearSessionCookie(res);
  res.json({ ok: true });
});

// معلومات المستخدم الحالي (للفرونت إند يعرف إذا مسجل دخول)
router.get('/me', requireAuth, async (req, res) => {
  const user = await getPublicUser(req.discordUserId);
  if (!user) return res.status(404).json({ error: 'not_found' });
  res.json(user);
});

export default router;
