// ============================================================
//   Cortex AI Dashboard — Servers Grid View
// ============================================================
import { api } from './api.js';
import { t } from './i18n.js';
import { showToast } from './toast.js';

function initials(name) {
  return (name || '?').trim().slice(0, 2).toUpperCase();
}

function renderServerCard(guild) {
  const statusBadge = guild.installed
    ? `<span class="badge ${guild.isActive ? 'badge-on' : 'badge-off'}">${guild.isActive ? t('servers.status_active') : t('servers.status_inactive')}</span>`
    : '';

  const actionBtn = guild.installed
    ? `<a href="/server.html?id=${guild.id}" class="btn btn-primary">${t('servers.btn_manage')}</a>`
    : `<a href="${guild.inviteUrl}" target="_blank" rel="noopener" class="btn">${t('servers.btn_invite')}</a>`;

  const iconHtml = guild.icon
    ? `<img src="${guild.icon}" alt="">`
    : initials(guild.name);

  return `
    <div class="card server-card">
      <div class="server-card-top">
        <div class="server-icon">${iconHtml}</div>
        <div style="min-width:0; flex:1;">
          <div class="server-name">${escapeHtml(guild.name)}</div>
          ${statusBadge}
        </div>
      </div>
      <div class="server-card-footer">
        ${actionBtn}
      </div>
    </div>
  `;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

export async function renderServersPage(container) {
  container.innerHTML = `
    <div class="page-header">
      <div class="page-eyebrow mono">${t('servers.eyebrow')}</div>
      <h1 class="page-title">${t('servers.title')}</h1>
      <p class="page-desc">${t('servers.desc')}</p>
    </div>
    <div id="serversContainer">
      <div class="loading-state">
        <span class="spinner"></span>
        <span>${t('servers.loading')}</span>
      </div>
    </div>
  `;

  const target = container.querySelector('#serversContainer');

  try {
    const guilds = await api.listGuilds();

    if (!guilds.length) {
      target.innerHTML = `
        <div class="empty-state">
          <div style="font-size:32px; margin-bottom:8px;">📭</div>
          <div style="font-weight:600;">${t('servers.empty_title')}</div>
          <p>${t('servers.empty_desc')}</p>
        </div>
      `;
      return;
    }

    // رتب: المفعّلة أولاً
    guilds.sort((a, b) => (b.installed - a.installed));

    target.innerHTML = `<div class="servers-grid">${guilds.map(renderServerCard).join('')}</div>`;
  } catch (e) {
    target.innerHTML = `
      <div class="empty-state">
        <div style="font-size:32px; margin-bottom:8px;">⚠️</div>
        <div style="font-weight:600;">${t('common.error_generic')}</div>
        <button class="btn" id="retryBtn" style="margin-top:16px;">${t('common.retry')}</button>
      </div>
    `;
    target.querySelector('#retryBtn')?.addEventListener('click', () => renderServersPage(container));
  }
}
