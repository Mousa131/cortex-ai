// ============================================================
//   Cortex AI Dashboard — i18n
// ============================================================
const SUPPORTED = ['ar', 'en'];
const STORAGE_KEY = 'cortex_lang';

let dict = {};
let currentLang = 'ar';

function getNested(obj, pathStr) {
  return pathStr.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
}

export function t(key) {
  const val = getNested(dict, key);
  return val !== undefined ? val : key;
}

export function getLang() {
  return currentLang;
}

export async function setLang(lang) {
  if (!SUPPORTED.includes(lang)) lang = 'ar';
  currentLang = lang;
  localStorage.setItem(STORAGE_KEY, lang);

  const res = await fetch(`/locales/${lang}.json`);
  dict = await res.json();

  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.setAttribute('lang', lang);

  applyTranslations();
  window.dispatchEvent(new CustomEvent('langchange', { detail: lang }));
}

export function applyTranslations(root = document) {
  root.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });
  root.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = t(el.getAttribute('data-i18n-placeholder'));
  });
}

export async function initI18n() {
  const saved = localStorage.getItem(STORAGE_KEY);
  const browserLang = navigator.language?.startsWith('ar') ? 'ar' : 'en';
  await setLang(saved || browserLang || 'ar');
}
