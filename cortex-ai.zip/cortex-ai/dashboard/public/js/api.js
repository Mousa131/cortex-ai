// ============================================================
//   Cortex AI Dashboard — API Client
// ============================================================

class ApiError extends Error {
  constructor(status, data) {
    super(data?.message || data?.error || `HTTP ${status}`);
    this.status = status;
    this.data = data;
  }
}

async function request(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'same-origin', // يضمن إرسال الكوكي مع كل طلب
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });

  let data = null;
  try { data = await res.json(); } catch { /* قد لا يكون فيه body */ }

  if (!res.ok) throw new ApiError(res.status, data);
  return data;
}

export const api = {
  me: () => request('/auth/me'),
  logout: () => request('/auth/logout', { method: 'POST' }),

  listGuilds: () => request('/api/guilds'),
  getGuildSettings: (guildId) => request(`/api/guilds/${guildId}/settings`),
  updateGuildSettings: (guildId, fields) =>
    request(`/api/guilds/${guildId}/settings`, { method: 'PATCH', body: JSON.stringify(fields) }),
  getGuildStats: (guildId) => request(`/api/guilds/${guildId}/stats`),
};

export { ApiError };
