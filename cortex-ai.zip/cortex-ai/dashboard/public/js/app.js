// ============================================================
//   Cortex AI Dashboard — App Controller
// ============================================================
import { initI18n, setLang, getLang } from './i18n.js';
import { api } from './api.js';
import { renderServersPage } from './serversView.js';
import { renderEditorPage } from './editorView.js';

async function boot() {
  await initI18n();

  // ── التحقق من تسجيل الدخول ──
  let user;
  try {
    user = await api.me();
  } catch {
    window.location.href = '/index.html';
    return;
  }

  setupUserChip(user);
  setupLangToggle();
  setupSidebar();
  setupLogout();

  const content = document.getElementById('appContent');
  const params = new URLSearchParams(window.location.search);
  const guildId = params.get('id');

  // راوتر بسيط جداً (لا حاجة لمكتبة بهالحجم من المشروع)
  if (window.location.pathname.includes('server.html') && guildId) {
    document.getElementById('cmdPath').textContent = `~/dashboard/${guildId}`;
    await renderEditorPage(content, guildId);
  } else {
    document.getElementById('cmdPath').textContent = '~/dashboard';
    await renderServersPage(content);
  }
}

function setupUserChip(user) {
  const avatarEl = document.getElementById('userAvatar');
  const nameEl = document.getElementById('userName');
  if (!avatarEl || !nameEl) return;

  nameEl.textContent = user.username;
  avatarEl.src = user.avatar
    ? `https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.png`
    : `https://cdn.discordapp.com/embed/avatars/0.png`;
}

function setupLangToggle() {
  function syncActive() {
    document.querySelectorAll('.lang-toggle button').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.lang === getLang());
    });
  }
  syncActive();

  document.querySelectorAll('.lang-toggle button').forEach(btn => {
    btn.addEventListener('click', async () => {
      await setLang(btn.dataset.lang);
      syncActive();
      // أعد رسم الصفحة الحالية بعد تغيير اللغة
      boot();
    });
  });
}

function setupSidebar() {
  const hamburger = document.getElementById('hamburgerBtn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  if (!hamburger || !sidebar || !overlay) return;

  const open = () => { sidebar.classList.add('open'); overlay.classList.add('open'); };
  const close = () => { sidebar.classList.remove('open'); overlay.classList.remove('open'); };

  hamburger.addEventListener('click', open);
  overlay.addEventListener('click', close);
}

function setupLogout() {
  const btn = document.getElementById('logoutBtnMobile');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    try { await api.logout(); } finally { window.location.href = '/index.html'; }
  });
}

boot();
