// ============================================================
//   Cortex AI Dashboard — Server Editor View
// ============================================================
import { api, ApiError } from './api.js';
import { t, getLang } from './i18n.js';
import { showToast } from './toast.js';

const PROMPT_MAX = 4000;

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

export async function renderEditorPage(container, guildId) {
  container.innerHTML = `
    <a href="/dashboard.html" class="back-link">← ${t('editor.back')}</a>
    <div class="loading-state">
      <span class="spinner"></span>
      <span>${t('common.loading')}</span>
    </div>
  `;

  let settings, stats;
  try {
    settings = await api.getGuildSettings(guildId);
  } catch (e) {
    return renderError(container, e);
  }

  try {
    stats = await api.getGuildStats(guildId);
  } catch {
    stats = { totalMessages: 0, totalTokens: 0, activeSessions: 0 };
  }

  let state = { ...settings };
  let dirty = false;

  container.innerHTML = `
    <a href="/dashboard.html" class="back-link">← ${t('editor.back')}</a>

    <div class="editor-header">
      <div class="server-icon">${state.guildIcon ? `<img src="${state.guildIcon}" alt="">` : (state.guildName || '?').slice(0,2).toUpperCase()}</div>
      <div>
        <h1 class="page-title">${escapeHtml(state.guildName)}</h1>
        <span class="badge ${state.isActive ? 'badge-on' : 'badge-off'}" id="statusBadge">
          ${state.isActive ? t('servers.status_active') : t('servers.status_inactive')}
        </span>
      </div>
    </div>

    <div class="stats-grid">
      <div class="card stat-card">
        <div class="stat-value mono">${stats.totalMessages}</div>
        <div class="stat-label">${t('editor.stat_messages')}</div>
      </div>
      <div class="card stat-card">
        <div class="stat-value mono">${stats.totalTokens}</div>
        <div class="stat-label">${t('editor.stat_tokens')}</div>
      </div>
      <div class="card stat-card">
        <div class="stat-value mono">${stats.activeSessions}</div>
        <div class="stat-label">${t('editor.stat_sessions')}</div>
      </div>
    </div>

    <div class="tabs">
      <button class="tab-btn active" data-tab="general">${t('editor.tab_general')}</button>
      <button class="tab-btn" data-tab="prompt">${t('editor.tab_prompt')}</button>
    </div>

    <div class="tab-panel active" data-panel="general">
      <div class="card">
        <div class="field">
          <label>${t('editor.label_bot_name')}</label>
          <input type="text" id="botName" value="${escapeHtml(state.botName)}" maxlength="50">
          <div class="field-hint">${t('editor.hint_bot_name')}</div>
        </div>

        <div class="settings-row">
          <div>
            <div class="settings-row-label">${t('editor.label_status')}</div>
            <div class="settings-row-desc">${t('editor.desc_status')}</div>
          </div>
          <label class="switch">
            <input type="checkbox" id="isActive" ${state.isActive ? 'checked' : ''}>
            <span class="switch-track"></span>
          </label>
        </div>

        <div class="field" style="margin-top:20px;">
          <label>${t('editor.label_language')}</label>
          <select id="language">
            <option value="ar" ${state.language === 'ar' ? 'selected' : ''}>العربية</option>
            <option value="en" ${state.language === 'en' ? 'selected' : ''}>English</option>
          </select>
          <div class="field-hint">${t('editor.hint_language')}</div>
        </div>

        <div class="field">
          <label>${t('editor.label_mode')}</label>
          <select id="mode">
            <option value="thread" ${state.mode === 'thread' ? 'selected' : ''}>${t('editor.mode_thread')}</option>
            <option value="channel" ${state.mode === 'channel' ? 'selected' : ''}>${t('editor.mode_channel')}</option>
          </select>
          <div class="field-hint">${t('editor.hint_mode')}</div>
        </div>
      </div>
    </div>

    <div class="tab-panel" data-panel="prompt">
      <div class="card">
        <div class="field">
          <label>${t('editor.label_prompt')}</label>
          <textarea id="systemPrompt" rows="14" maxlength="${PROMPT_MAX}">${escapeHtml(state.systemPrompt)}</textarea>
          <div class="prompt-meta">
            <span>${t('editor.hint_prompt')}</span>
            <span id="promptCount" class="mono">${state.systemPrompt.length} / ${PROMPT_MAX}</span>
          </div>
        </div>

        <div class="field">
          <label>${t('editor.label_temperature')}</label>
          <div class="range-row">
            <input type="range" id="temperature" min="0" max="1" step="0.1" value="${state.temperature}">
            <span class="range-value mono" id="temperatureValue">${state.temperature}</span>
          </div>
          <div class="field-hint">${t('editor.hint_temperature')}</div>
        </div>

        <div class="field">
          <label>${t('editor.label_max_tokens')}</label>
          <div class="range-row">
            <input type="range" id="maxTokens" min="50" max="2000" step="50" value="${state.maxTokens}">
            <span class="range-value mono" id="maxTokensValue">${state.maxTokens}</span>
          </div>
          <div class="field-hint">${t('editor.hint_max_tokens')}</div>
        </div>
      </div>
    </div>

    <div class="save-bar">
      <button class="btn btn-primary" id="saveBtn">${t('editor.btn_save')}</button>
    </div>
  `;

  // ── منطق التبويبات ──
  container.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      container.querySelector(`[data-panel="${btn.dataset.tab}"]`).classList.add('active');
    });
  });

  // ── عناصر التحكم ──
  const els = {
    botName: container.querySelector('#botName'),
    isActive: container.querySelector('#isActive'),
    language: container.querySelector('#language'),
    mode: container.querySelector('#mode'),
    systemPrompt: container.querySelector('#systemPrompt'),
    promptCount: container.querySelector('#promptCount'),
    temperature: container.querySelector('#temperature'),
    temperatureValue: container.querySelector('#temperatureValue'),
    maxTokens: container.querySelector('#maxTokens'),
    maxTokensValue: container.querySelector('#maxTokensValue'),
    saveBtn: container.querySelector('#saveBtn'),
    statusBadge: container.querySelector('#statusBadge'),
  };

  els.systemPrompt.addEventListener('input', () => {
    const len = els.systemPrompt.value.length;
    els.promptCount.textContent = `${len} / ${PROMPT_MAX}`;
    els.promptCount.classList.toggle('over', len >= PROMPT_MAX);
  });

  els.temperature.addEventListener('input', () => {
    els.temperatureValue.textContent = els.temperature.value;
  });

  els.maxTokens.addEventListener('input', () => {
    els.maxTokensValue.textContent = els.maxTokens.value;
  });

  els.saveBtn.addEventListener('click', async () => {
    const payload = {
      botName: els.botName.value.trim(),
      isActive: els.isActive.checked,
      language: els.language.value,
      mode: els.mode.value,
      systemPrompt: els.systemPrompt.value,
      temperature: parseFloat(els.temperature.value),
      maxTokens: parseInt(els.maxTokens.value, 10),
    };

    if (!payload.botName) {
      showToast(t('editor.save_error'), 'error');
      return;
    }

    els.saveBtn.disabled = true;
    els.saveBtn.innerHTML = `<span class="spinner"></span> ${t('editor.btn_saving')}`;

    try {
      await api.updateGuildSettings(guildId, payload);
      showToast(t('editor.saved'));

      els.statusBadge.textContent = payload.isActive ? t('servers.status_active') : t('servers.status_inactive');
      els.statusBadge.className = `badge ${payload.isActive ? 'badge-on' : 'badge-off'}`;
    } catch (e) {
      const msg = e instanceof ApiError && e.data?.message ? e.data.message : t('editor.save_error');
      showToast(msg, 'error');
    } finally {
      els.saveBtn.disabled = false;
      els.saveBtn.textContent = t('editor.btn_save');
    }
  });
}

function renderError(container, e) {
  const isForbidden = e instanceof ApiError && e.status === 403;
  const isNotFound = e instanceof ApiError && e.status === 404;

  let message = t('common.error_generic');
  if (isForbidden) message = t('common.error_forbidden');

  container.innerHTML = `
    <a href="/dashboard.html" class="back-link">← ${t('editor.back')}</a>
    <div class="empty-state">
      <div style="font-size:32px; margin-bottom:8px;">${isForbidden ? '🔒' : '⚠️'}</div>
      <div style="font-weight:600;">${message}</div>
    </div>
  `;
}
