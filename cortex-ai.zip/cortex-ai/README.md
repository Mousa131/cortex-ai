# 🧠 Cortex AI

بوت ديسكورد ذكاء اصطناعي (Mistral) متعدد السيرفرات — كل سيرفر له System Prompt وإعدادات مستقلة تُدار من داشبورد ويب.

## البنية

```
cortex-ai/
├── bot/                  ← بوت Discord (discord.js v14)
│   └── index.js
├── dashboard/
│   ├── server/           ← Express backend (API + OAuth)
│   └── public/            ← الموقع (HTML/CSS/JS عادي، بدون فريموورك)
├── shared/                ← كود مشترك بين البوت والداشبورد (DB, AI, إلخ)
├── database/
│   └── schema.sql         ← هيكل قاعدة البيانات (PostgreSQL)
├── .env.example
└── package.json
```

البوت والداشبورد **عمليتان منفصلتان** تتشاركان نفس قاعدة البيانات (Neon). تقدر تشغّلهم على نفس السيرفر أو سيرفرين مختلفين.

---

## 1. الإعداد الأولي

```bash
npm install
cp .env.example .env
```

افتح `.env` واملأ القيم التالية:

| المتغير | المصدر |
|---|---|
| `DISCORD_CLIENT_ID` | Discord Developer Portal → OAuth2 → General |
| `DISCORD_CLIENT_SECRET` | نفس الصفحة (Reset Secret) |
| `DISCORD_BOT_TOKEN` | Discord Developer Portal → Bot (Reset Token) |
| `DISCORD_REDIRECT_URI` | لازم يطابق بالضبط الرابط المسجل بـ OAuth2 → Redirects |
| `DATABASE_URL` | Neon connection string |
| `MISTRAL_API_KEY` | Mistral AI dashboard |
| `SESSION_SECRET` | ولّده بنفسك (انظر الأمر تحت) |
| `PUBLIC_URL` | دومين موقعك الفعلي وقت الإنتاج |

لتوليد `SESSION_SECRET` آمن:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

**⚠️ مهم:** الـ Bot Token والـ Client Secret اللي استخدمتها أثناء بناء هذا المشروع معي ظهرت بمحادثة الشات — لازم تعمل **Reset** لها من Discord Developer Portal قبل أي استخدام فعلي، وتحدّث `.env` بالقيم الجديدة.

---

## 2. إعداد Discord Application

1. **OAuth2 → General → Redirects**: ضيف
   - `http://localhost:3000/auth/discord/callback` (للتجربة المحلية)
   - `https://YOUR_DOMAIN/auth/discord/callback` (للإنتاج، بعد ما يصير عندك دومين)
2. **Bot → Privileged Gateway Intents**: فعّل
   - ✅ MESSAGE CONTENT INTENT
   - ✅ SERVER MEMBERS INTENT (اختياري، للتوسعة المستقبلية)
3. **OAuth2 → URL Generator** (مرجعي فقط — الكود يبني الرابط تلقائياً):
   - Scopes: `bot`, `applications.commands`
   - Bot Permissions: View Channels, Send Messages, Read Message History, Create Private Threads, Send Messages in Threads, Manage Threads, Embed Links, Use External Emojis

---

## 3. قاعدة البيانات

السكيما تُنشأ تلقائياً عند أول تشغيل للداشبورد (`ensureSchema()` بـ `server.js`). لو تبي تشغلها يدوياً:

```bash
psql "$DATABASE_URL" -f database/schema.sql
```

---

## 4. التشغيل

شغّل العمليتين في تيرمنالين منفصلين (أو استخدم pm2 بالإنتاج):

```bash
# Terminal 1 — البوت
npm run bot

# Terminal 2 — الداشبورد
npm run dashboard
```

افتح `http://localhost:3000` وسجّل دخول بديسكورد.

---

## 5. تشغيل البوت داخل سيرفر Discord

1. سجّل دخول بالداشبورد
2. بصفحة "السيرفرات" بتشوف كل سيرفراتك (اللي عندك فيها صلاحية إدارة)
3. اضغط "إضافة البوت" على أي سيرفر مو مفعّل فيه بعد
4. بعد ما ينضم البوت، روح بديسكورد واكتب `/setup` بأي روم (يحتاج صلاحية Manage Server)
5. راح يظهر زر "بدء محادثة جديدة" — أي عضو يضغطه يفتح له ثريد خاص يقدر يسأل فيه البوت

---

## 6. تعديل برومت سيرفر

بالداشبورد: اضغط "تعديل البوت" على أي سيرفر مفعّل → تبويب "البرومت" → عدّل النص → "حفظ التغييرات".
التغيير ينعكس فوراً على ردود البوت بذلك السيرفر فقط.

---

## ملاحظات أمان مهمة

- **مفتاح Mistral API لا يظهر أبداً بالفرونت إند** — يُستخدم فقط من السيرفر (`shared/mistral.js`)، ولا يوجد أي route يرجّعه للمستخدم.
- **كل تعديل لإعدادات سيرفر يتحقق من صلاحية `MANAGE_GUILD`** بالـ backend (`requireGuildManager` middleware) — مو فقط بإخفاء الأزرار بالواجهة.
- **الجلسات محفوظة بكوكي HttpOnly موقّع بـ JWT** — غير قابلة للقراءة من JavaScript، أأمن من `localStorage` ضد XSS.
- **OAuth flow محمي بـ `state` عشوائي** يمنع هجمات CSRF أثناء تسجيل الدخول.
- كل القيم القادمة من المستخدم (system prompt، اسم البوت، إلخ) تُتحقق منها (طول، نوع، مدى) قبل الحفظ بالداتابيس.

---

## التوسعة المستقبلية (أفكار)

- إضافة مزودي AI إضافيين (OpenAI, إلخ) — البنية بـ `shared/mistral.js` مصممة عشان تقدر تضيف ملف موازي وتبدّل حسب إعداد كل سيرفر
- سجل محادثات قابل للعرض بالداشبورد (الجدول `usage_logs` موجود أصلاً كأساس)
- تجديد تلقائي للـ Discord access token عبر `refresh_token` المخزّن (حالياً صالح 7 أيام بالكوكي، لكن لو احتجت تستخدم access token لطلبات أخرى بعد انتهائه، تحتاج تضيف منطق refresh)
